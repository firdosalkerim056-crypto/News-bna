NEWS Bikolos Nur Academy
=======================
Full Django newspaper scaffold with search, user roles, article approval workflow, Tailwind styling.
Includes dummy content for presentation.

Apps included:
- accounts: Users & roles, invite system
- news: Sections, posts, comments, search
- core: School info, site settings

Templates: base.html, home.html, search_results.html
Static & media folders included
.env.example and requirements.txt ready for deployment

Next steps:
1. python -m venv venv
2. pip install -r requirements.txt
3. python manage.py migrate
4. python manage.py createsuperuser
5. python manage.py runserver
